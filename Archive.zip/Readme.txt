 CS 1571 Homework 3 Programming Assignment README.txt

 By Chris Grant 

 This project is written in python 3.6.2 but should work in any version of python 3. 

 In order to run this project, you need the following python libraries, they should be installed by default, but on the off chance they are not: 
    itertools
    collections
    sys

In terms of outside resources I used, I found the link below on a UC Berkeley website, which contains a basic implementation of a knowlege base. 
From there I modified that code for the First Order Logic Knowlege Base class (FOLKB) and the Expression class (expr) used in my code.

From there I wrote my unifcation algorthm based on the instructions on the assignment page, and finally wrote the forward chaining algorithm and the incremental
 varriant based on figure 9.3 of the textbook. 

 The link is: http://aima.cs.berkeley.edu/python/logic.html

 I discussed this project with Ryan Yoder and Paul Davis, and we talked about the implementation of the knowlege base and the expression classes
 

